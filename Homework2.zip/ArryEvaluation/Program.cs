﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArryEvaluation
{
    class ArrayEvaluation
    {
        static int setArry(ref int[] arry)
        {
            int length = 0;
            Console.WriteLine("Please set the length of this arry");
            bool posInt = int.TryParse(Console.ReadLine(), out length);
            if (length <= 0)
            {
                Console.WriteLine("Please input a POSITIVE INTEGER!\n");
            }
            arry = new int[length];
            Console.WriteLine("The length of this arry is:" + length);
            Console.WriteLine("Please input some integer in this arry");
            try
            {
                for (int i = 0; i < length; i++)
                {
                    arry[i] = int.Parse(Console.ReadLine());
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("An Exception occured:" + e.Message);
            }
            Console.WriteLine("Your arry is:");
            for (int i = 0; i < length; i++)
            {
                Console.WriteLine(arry[i] + "\t");
            }
            return 0;
        }
        static void getMaxNum(int[] arry)
        {
            int max = arry[0];
            for (int i = 1; i < arry.Length; i++)
            {
                max = max > arry[i] ? max : arry[i];
            }
            Console.WriteLine("The max number in this arry is:" + max);
        }
        static void getMinNum(int[] arry)
        {
            int min = arry[0];
            for (int i = 1; i < arry.Length; i++)
            {
                min = min < arry[i] ? min : arry[i];
            }
            Console.WriteLine("The min number in this arry is:" + min);
        }
        static void getAverage(int[] arry)
        {
            int ave = 0;
            int sum = 0;
            foreach (int a in arry)
            {
                sum += a;
            }
            ave = sum / arry.Length;
            Console.WriteLine("The average of this arry is:" + ave);
        }
        static void getSum(int[] arry)
        {
            int sum = 0;
            foreach (int a in arry)
            {
                sum += a;
            }
            Console.WriteLine("The summation of this arry is:" + sum);

        }
        static void Main(string[] args)
        {
            int[] a = { };
            setArry(ref a);
            getMaxNum(a);
            getMinNum(a);
            getAverage(a);
            getSum(a);
            Console.ReadKey();
        }
    }
}
