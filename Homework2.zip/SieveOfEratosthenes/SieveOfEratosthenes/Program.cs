﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SieveOfEratosthenes
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> list = new List<int> { };
            for(int i = 2; i <= 100; i++)
            {
                list.Add(i);
            }
            for(int i = 2; i <= 10; i++)
            {
                for(int j = 2; j <= 100; j++)
                {
                    if(j>i&&j%i==0)
                    {
                        list.Remove(j);
                    }
                }
            }
            foreach(int item in list)
            {
                Console.Write("{0}\t", item);
            }
            Console.ReadKey();
        }
    }
}
