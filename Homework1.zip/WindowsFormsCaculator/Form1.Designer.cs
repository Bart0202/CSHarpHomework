﻿namespace WindowsFormsCaculator
{
    partial class FormOfCaculator
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClickToCaculate = new System.Windows.Forms.Button();
            this.lblNum1 = new System.Windows.Forms.Label();
            this.lblNum2 = new System.Windows.Forms.Label();
            this.txbNum1 = new System.Windows.Forms.TextBox();
            this.txbNum2 = new System.Windows.Forms.TextBox();
            this.cmbOp = new System.Windows.Forms.ComboBox();
            this.lblOp = new System.Windows.Forms.Label();
            this.lblOprator = new System.Windows.Forms.Label();
            this.labEq = new System.Windows.Forms.Label();
            this.txbResult = new System.Windows.Forms.TextBox();
            this.lblResul = new System.Windows.Forms.Label();
            this.lblMessage = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnClickToCaculate
            // 
            this.btnClickToCaculate.Location = new System.Drawing.Point(395, 204);
            this.btnClickToCaculate.Name = "btnClickToCaculate";
            this.btnClickToCaculate.Size = new System.Drawing.Size(75, 23);
            this.btnClickToCaculate.TabIndex = 0;
            this.btnClickToCaculate.Text = "计算";
            this.btnClickToCaculate.UseVisualStyleBackColor = true;
            this.btnClickToCaculate.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblNum1
            // 
            this.lblNum1.AutoSize = true;
            this.lblNum1.Location = new System.Drawing.Point(71, 79);
            this.lblNum1.Name = "lblNum1";
            this.lblNum1.Size = new System.Drawing.Size(47, 12);
            this.lblNum1.TabIndex = 1;
            this.lblNum1.Text = "Number1";
            // 
            // lblNum2
            // 
            this.lblNum2.AutoSize = true;
            this.lblNum2.Location = new System.Drawing.Point(231, 79);
            this.lblNum2.Name = "lblNum2";
            this.lblNum2.Size = new System.Drawing.Size(47, 12);
            this.lblNum2.TabIndex = 2;
            this.lblNum2.Text = "Number2";
            this.lblNum2.Click += new System.EventHandler(this.lblNum2_Click);
            // 
            // txbNum1
            // 
            this.txbNum1.Location = new System.Drawing.Point(45, 94);
            this.txbNum1.Name = "txbNum1";
            this.txbNum1.Size = new System.Drawing.Size(100, 21);
            this.txbNum1.TabIndex = 3;
            // 
            // txbNum2
            // 
            this.txbNum2.Location = new System.Drawing.Point(202, 94);
            this.txbNum2.Name = "txbNum2";
            this.txbNum2.Size = new System.Drawing.Size(100, 21);
            this.txbNum2.TabIndex = 4;
            this.txbNum2.TextChanged += new System.EventHandler(this.txbNum2_TextChanged);
            // 
            // cmbOp
            // 
            this.cmbOp.FormattingEnabled = true;
            this.cmbOp.Items.AddRange(new object[] {
            "+",
            "-",
            "*",
            "/"});
            this.cmbOp.Location = new System.Drawing.Point(153, 95);
            this.cmbOp.MaxDropDownItems = 4;
            this.cmbOp.Name = "cmbOp";
            this.cmbOp.Size = new System.Drawing.Size(43, 20);
            this.cmbOp.TabIndex = 5;
            this.cmbOp.SelectedIndexChanged += new System.EventHandler(this.cmbOp_SelectedIndexChanged);
            // 
            // lblOp
            // 
            this.lblOp.AutoSize = true;
            this.lblOp.Location = new System.Drawing.Point(147, 97);
            this.lblOp.Name = "lblOp";
            this.lblOp.Size = new System.Drawing.Size(0, 12);
            this.lblOp.TabIndex = 6;
            // 
            // lblOprator
            // 
            this.lblOprator.AutoSize = true;
            this.lblOprator.Location = new System.Drawing.Point(151, 79);
            this.lblOprator.Name = "lblOprator";
            this.lblOprator.Size = new System.Drawing.Size(47, 12);
            this.lblOprator.TabIndex = 7;
            this.lblOprator.Text = "Oprator";
            // 
            // labEq
            // 
            this.labEq.AutoSize = true;
            this.labEq.Location = new System.Drawing.Point(308, 98);
            this.labEq.Name = "labEq";
            this.labEq.Size = new System.Drawing.Size(11, 12);
            this.labEq.TabIndex = 8;
            this.labEq.Text = "=";
            // 
            // txbResult
            // 
            this.txbResult.Location = new System.Drawing.Point(325, 94);
            this.txbResult.Name = "txbResult";
            this.txbResult.Size = new System.Drawing.Size(100, 21);
            this.txbResult.TabIndex = 9;
            // 
            // lblResul
            // 
            this.lblResul.AutoSize = true;
            this.lblResul.Location = new System.Drawing.Point(356, 79);
            this.lblResul.Name = "lblResul";
            this.lblResul.Size = new System.Drawing.Size(41, 12);
            this.lblResul.TabIndex = 10;
            this.lblResul.Text = "Result";
            this.lblResul.Click += new System.EventHandler(this.lblResul_Click);
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.Location = new System.Drawing.Point(43, 155);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(47, 12);
            this.lblMessage.TabIndex = 11;
            this.lblMessage.Text = "Message\r\n";
            // 
            // FormOfCaculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(538, 277);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.lblResul);
            this.Controls.Add(this.txbResult);
            this.Controls.Add(this.labEq);
            this.Controls.Add(this.lblOprator);
            this.Controls.Add(this.lblOp);
            this.Controls.Add(this.cmbOp);
            this.Controls.Add(this.txbNum2);
            this.Controls.Add(this.txbNum1);
            this.Controls.Add(this.lblNum2);
            this.Controls.Add(this.lblNum1);
            this.Controls.Add(this.btnClickToCaculate);
            this.Name = "FormOfCaculator";
            this.Text = "Caculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnClickToCaculate;
        private System.Windows.Forms.Label lblNum1;
        private System.Windows.Forms.Label lblNum2;
        private System.Windows.Forms.TextBox txbNum1;
        private System.Windows.Forms.TextBox txbNum2;
        private System.Windows.Forms.ComboBox cmbOp;
        private System.Windows.Forms.Label lblOp;
        private System.Windows.Forms.Label lblOprator;
        private System.Windows.Forms.Label labEq;
        private System.Windows.Forms.TextBox txbResult;
        private System.Windows.Forms.Label lblResul;
        private System.Windows.Forms.Label lblMessage;
    }
}

