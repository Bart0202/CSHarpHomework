﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework2
{
    class GetPrimeFactor
    {
        static int getInput()
        {
            int num = 0;
            Console.WriteLine("Please input a positive integer");
            bool posInt=int.TryParse(Console.ReadLine(),out num);
            if(!posInt||num<=0)
            {
                Console.WriteLine("Please input a POSITIVE INTEGER!\n");
                return getInput();
            }
            return num;
        }

        static void outputResult(int num)
        {
            Console.WriteLine("The prime factors of this number are:");
            for(int i=2;i<=num; i++)
            {
                if (num % i == 0)
                {
                    Console.Write(i + "\t");
                }
            }
        }
        static void Main(string[] args)
        {
            int num = getInput();
            outputResult(num);
            Console.ReadKey();
        }
    }
}
