﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsCaculator
{
    public partial class FormOfCaculator : Form
    {
        public FormOfCaculator()
        {
            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double num1 = 0;
            double num2 = 0;
            double result = 0;

            try
            {
                num1 = Convert.ToDouble(txbNum1.Text);
                num2 = Convert.ToDouble(txbNum2.Text);
                switch (cmbOp.SelectedItem)
                {
                    case "+":
                        result = num1 + num2;
                        break;
                    case "-":
                        result = num1 - num2;
                        break;
                    case "*":
                        result = num1 * num2;
                        break;
                    case "/":
                        if (num2 == 0)
                        {
                            lblMessage.Text = "error:divisor is zero.";
                            txbNum1.Text = "";
                            txbNum2.Text = "";
                        }
                        result = num1 / num2;
                        break;
                    default:
                        lblMessage.Text = "Please select operator.";
                        break;
                }
            }
            catch (FormatException)
            {
                lblMessage.Text = "Error:inputted format is error.";
                txbNum1.Text = "";
                txbNum2.Text = "";
            }
            catch (OverflowException)
            {
                lblMessage.Text = "Error:inputted number is overflow.";
                txbNum1.Text = "";
                txbNum2.Text = "";
            }
            txbResult.Text = Convert.ToString(result);

        }

        private void lblNum2_Click(object sender, EventArgs e)
        {

        }

        private void txbNum2_TextChanged(object sender, EventArgs e)
        {

        }

        private void cmbOp_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lblResul_Click(object sender, EventArgs e)
        {

        }
    } 
}
